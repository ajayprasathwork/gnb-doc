import React, { useState,useEffect } from 'react';
import { db } from '../apiservice/fbconf';
import {getComposeMeta} from '../apiservice/docapi';
import { onValue, ref } from 'firebase/database';
import ReactLoading from "react-loading";
import Modal from 'react-modal';
import { Tooltip as ReactTooltip } from "react-tooltip";
import '../../styles.css';
const customStyles = {
  content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      width: '100%',
      height: '100%',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
  },
};
const Compose = () => {
    const [file, setFile] = useState([]);
    const [loading,setLoading]=useState(false)
    const [error,setError]=useState(false)
    const [modalIsOpen, setIsOpen] = useState(false);
    const [modelloading,setModelLoading]=useState(false);
    const [attachments,setAttachments]=useState([]);
    const [signature_person,setSignature_person]=useState([]);
    const [mergeFields,setMergeFields]=useState([]);
    const [signature,setSignature]=useState([]);
    const [property_id,setProperty_id]=useState("");
    const [title,setTitle]=useState("");

    useEffect(() => {
        let iscompose=JSON.parse(localStorage.getItem('compose'))
        console.log(iscompose)
        if(iscompose){
          setModelLoading(true)
          Word.run(async context => {
            context.document.body.clear();
            getDocFileUrlToBlob(iscompose.document_url, function (dataUrl) {
                var blob = dataUrl.replace('data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,', '');
                var myNewDoc = context.application.createDocument(blob);
                context.document.body.insertFileFromBase64(blob, "start");
                context.sync();
                context.sync()
                    .then(function () {
                        myNewDoc.open()
                   }).catch(function (myError) {
                        console.log("Error", myError.message);
                    })
            })
        })
          setIsOpen(true);
          setModelLoading(false)
          callGetComposeMeta(iscompose)
        }else{
          loadList()
        }
      
      }, []);
      const callGetComposeMeta=async(item)=>{
        try {
            const user = JSON.parse(localStorage.getItem('user'));
            let data=JSON.stringify({source_id: item.source_id,document_id: item.document_id,source_type: item.source_type,app_board:user.app_board,app_token: user.app_token,app_uuid: 0,params: {}, title: item.document_title})
            const result = await getComposeMeta(data);
           if(result.success){
            setAttachments(result.response.attachments)
            setMergeFields(result.response.variables)
            setProperty_id(result.response.property_id)
            setTitle(result.response.title)
            setSignature_person(result.response.signature_person)
            setSignature(result.response.signature)
            setModelLoading(false)
            console.log(result.response)  
           }else{

           }
          } catch (error) {
            console.log(error)  
            setModelLoading(false)


          }
    }

      const loadList=()=>{
        setLoading(true)
        const user = JSON.parse(localStorage.getItem('user'));
        const query = ref(db, `dev/${user.app_board}/${user.user_id}`);
        return onValue(query, (snapshot) => {
          const data = snapshot.val();
          console.log(data)
          if (snapshot.exists()) {
            Object.values(data).map((item) => {
                setFile((file) => [...file, item]);
                console.log(item)
            });
            setLoading(false)
          }else{
             setError(true)
            setLoading(false)
          }
        });
      }

      function getDocFileUrlToBlob(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
          var reader = new FileReader();   
          reader.onloadend = function () {    
            callback(reader.result);   
          }   
          reader.readAsDataURL(xhr.response);     
        };
        xhr.open('GET', url);     
        xhr.responseType = 'blob';      
        xhr.send();
      
      }
      function closeModal() {
        localStorage.removeItem("compose");
        loadList();
        setIsOpen(false);
    }

function openFile(item) {
    Word.run(async context => {
        context.document.body.clear();
        getDocFileUrlToBlob(item.document_url, function (dataUrl) {
            var blob = dataUrl.replace('data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,', '');
            var myNewDoc = context.application.createDocument(blob);
            context.document.body.insertFileFromBase64(blob, "start");
            context.sync();
            context.sync()
                .then(function () {
                    localStorage.setItem('compose', JSON.stringify(item));
                    myNewDoc.open()
                    context.document.body.clear(); 
                    context.sync();
               }).catch(function (myError) {
                    console.log("Error", myError.message);
                    toast("File corrupted", myError.message);
                })
        })
    })
}
useEffect(()=>{
  search_replace();
},[mergeFields])

const search_replace=async()=> {
  console.log(mergeFields)
  if (mergeFields.length > 0) {
     Word.run(async (context) => {
      var body = context.document.body;
      var options = Word.SearchOptions.newObject(context);
      options.matchCase = true
      var searchResults = context.document.body.search(mergeFields[0].name, options);
      context.load(searchResults, 'text, font');
      return context.sync().then(() => {
        var results = 'Found count: ' + searchResults.items.length + '; we highlighted the results.' + mergeFields[0].name + '-Value-' + mergeFields[0].value;
        console.log(results);
        for (var i = 0; i < searchResults.items.length; i++) {
          if (mergeFields[0].isHTML) {
            searchResults.items[i].insertHtml(mergeFields[0].value, Word.InsertLocation.replace);
          } else {
            searchResults.items[i].insertText(mergeFields[0].value, Word.InsertLocation.replace);
          }
        }
        return context.sync().then(function () {
          let newarray=mergeFields.filter((item,index)=>!index==0)
         console.log(newarray)
         setMergeFields(newarray)
        });
      });
    })
      .catch(function (error) {
        if (error instanceof OfficeExtension.Error) {
        }
      });
  } else {   
  }

}

      if(loading){
        return(
            <div className='section'>
            <div style={{alignItems:'center',justifyContent:'center',height:"100%",width:'100%',display:'flex'}} className='main'>
            <ReactLoading
                type="spinningBubbles"
                color="#529B50"
                height={70}
                width={50}
            />
            </div>
        </div>
        )
       
      }
      if(error){
        return(
            <div className='section'>
            <div style={{justifyContent:'center',height:"100%",width:'100%',display:'flex'}} className='main'>
              <div className='nodata'>No data found</div>
            </div>
        </div>
        )
       
      }
    return (
        <div className='section'>
            <div className='d-flex ai-center jc-sp-between py-3'>
                <span className='des_sm'>List of files selected for editing</span>
                <a className='des_sm choose_link'></a>
            </div>

            <div className='card_list'>
                <div className='card_one'>
                    {file.map((item,index)=>{
                        return(
                            <a onClick={()=>openFile(item)} className='card_link'>
                            <p  className='des'>{index+1}.{item.document_title}</p>
                            <a className='badge_yellow des_sm'>This document will open in a new window.</a>
                            <div className='d-flex ai-center jc-sp-between card_des_info'>
                                <span className='des_sm'></span>
                                <span className='des_sm'>{item.document_type}</span>
                            </div>
                        </a>
                        )
                    })}
                  
                   
                </div>
            </div>
            <Modal
            isOpen={modalIsOpen}
            onAfterOpen={()=>{}}
            onRequestClose={closeModal}
            style={customStyles}
            contentLabel="Example Modal"
        >
          <div className='add_temp_head'>
                <h4 className="font_sm">Document</h4>
                <p className='des_sm'></p>
            </div> 
         {modelloading ? <div style={{height:'80%'}} className='section'>
            <div style={{alignItems:'center',justifyContent:'center',height:"100%",width:'100%',display:'flex'}} className='main'>
            <ReactLoading
                type="spinningBubbles"
                color="#529B50"
                height={70}
                width={50}
            />
            </div>
        </div> :<>
            <div className='add_temp_form'>
            <div style={{height:'100%',display:'flex'}} className='gnb_doc_form'>
              </div>
              
            </div>
            <div className="footer_btns">
                <p data-tooltip-id="my-tooltip-1"  style={{textAlign:'center'}}  className="des gnb_doc_btn">Upload  to AMC</p>  
                <p style={{textAlign:'center'}}  className="des gnb_doc_btn">Upload  to AMC</p>  
                <p style={{textAlign:'center'}}  className="des gnb_doc_btn">Save</p>
                <a className="des gnb_doc_link" onClick={closeModal}>Cancel</a>
                <ReactTooltip
        id="my-tooltip-1"
        place="bottom"
        content="Hello world! I'm a Tooltip"
      />
            </div>
            </>}

        </Modal>
       
        </div>
    )
}

export default Compose;